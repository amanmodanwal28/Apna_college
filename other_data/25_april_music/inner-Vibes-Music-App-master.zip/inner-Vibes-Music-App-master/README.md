
Inspired from Spotify, I have build a custom frontend for Music Player Web Application using HTML and CSS. Website contains static homepage, specific artist details page to display playlist and favourite list as well as some custom themes.
![music_player1](https://user-images.githubusercontent.com/88419331/173991590-89af50de-e3f9-4388-8061-ffe7c26d631d.png)
# inner-Vibes-Music-App![music_player2](https://user-images.githubusercontent.com/88419331/173991604-b107c32d-474d-4650-9cd4-49b11b1f3f63.png)
